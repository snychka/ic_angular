const { assert } = require('chai');
const { readFileSync } = require('fs');
const { Project } = require('ts-morph');
const get = require('lodash.get');

let userCode = readFileSync('./app.component.ts', 'utf-8')
const project = new Project();
const sourceFile = project.createSourceFile('./app-user.component.ts', userCode)

describe('Creating a class', () => {
  const userClass = sourceFile.getClass('AppComponent')
  const userClassIsExported = userClass ? userClass.isExported() : undefined
  const pageTitleProperty = userClass ? userClass.getProperty('pageTitle') : undefined
  const currentPromotionProperty = userClass ? userClass.getProperty('currentPromotion') : undefined
  const pageTitleIsCorrect = pageTitleProperty ?
    (pageTitleProperty.getType().getText() === 'string' &&
      get('pageTitleProperty', ['compilerNode', 'initializer', 'text']) === 'Carved Rock Fitness') :
    false
  const currentPromotionPropertyIsCorrect = currentPromotionProperty ?
    (currentPromotionProperty.getType().getText() === 'string' &&
      get('currentPromotionProperty', ['compilerNode', 'initializer', 'text']) === '20% off throughout the season') :
    false

  const passedAnswer = pageTitleIsCorrect && currentPromotionPropertyIsCorrect && userClassIsExported;

  describe('one', () => {
    it('f_AppComponent_class',() => {
        if (passedAnswer) return;
        assert(sourceFile.getClasses().length > 0, `First, we need to add an \`AppComponent\` class.`)
        assert(userClass, `Let's make sure our class is called \`AppComponent\`.`)
      }
    )
  })

  describe('two', () => {
    it('f_pageTitle_property', () => {
        if (passedAnswer) return;
        assert(sourceFile.getClasses().length > 0, `First, we need to add an \`AppComponent\` class.`)
        assert(userClass.getProperties().length > 0, `Oops, we need to add properties to our \`AppComponent\` class.`);
        assert(pageTitleProperty, `Let's make sure we've added \`pageTitle\` as a property to our \`AppComponent\`.`);
        assert(pageTitleProperty.getType().getText() === 'string', `Uh-oh, let's make sure our \`pageTitle\` property is a \`string\` type.`);
        assert(pageTitleProperty.compilerNode.initializer.text === 'Carved Rock Fitness', `Close, but we need to assign \`'Carved Rock Fitness'\` to our \`pageTitle\`.`);
      }
    )
  })

  describe('three', () => {
    it('f_currentPromotion_property', () => {
        if (passedAnswer) return;
        assert(sourceFile.getClasses().length > 0, `First, we need to add an \`AppComponent\` class.`)
        assert(userClass.getProperties().length > 0, `Oops, we need to add properties to our \`AppComponent\` class.`);
        assert(currentPromotionProperty, `Let's make sure we've added \`currentPromotion\` as a property to our \`AppComponent\`.`);
        assert(currentPromotionProperty.getType().getText() === 'string', `Uh-oh, let's make sure our \`currentPromotion\` property is a \`string\` type.`,);
        assert(currentPromotionProperty.compilerNode.initializer.text === '20% off throughout the season', `Close, but we need to assign \`20% off throughout the season\` to our \`currentPromotion\`.`);
      }
    )
  })

  describe('four', () => {
    it('f_class_not_exported', () => {
        if (passedAnswer) return;
        assert(sourceFile.getClasses().length > 0, `First, we need to add an \`AppComponent\` class.`)
        assert(userClass.isExported(), `Almost there! We just need to \`export\` our \`AppComponent\`.`);
      }
    )
  })
})
