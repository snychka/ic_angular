const { assert } = require('chai'),
  { readFileSync } = require('fs'),
  { Project } = require('ts-morph'),
  parse = require('rehype-parse'),
  { SyntaxKind } = require('typescript'),
  htmlTagValidator = require('html-tag-validator')

const userCode = readFileSync('./app.component.ts', 'utf-8')
const htmlCode = readFileSync('./index.html', 'utf-8')

const project = new Project()
const sourceFile = project.createSourceFile('./.compiled/app.component.ts', userCode)

describe('defining the metadata', () => {
  const decorator = sourceFile.getClass('AppComponent').getDecorator('Component')
  const decoratorComma = decorator && decorator.getFirstChildByKind(SyntaxKind.CallExpression)
    .getFirstChildByKind(SyntaxKind.SyntaxList)
    .getFirstChildByKind(SyntaxKind.ObjectLiteralExpression)
    .getFirstChildByKind(SyntaxKind.SyntaxList)
    .getFirstChildByKind(SyntaxKind.CommaToken)

  const properties = decorator ? decorator.getArguments()[0].compilerNode.properties : undefined
  const templateProp = properties && properties.find(prop => prop.name.escapedText === 'template')
  const templateHtml = templateProp && templateProp.initializer && templateProp.initializer.text

  const templateBacktick = decorator && properties && templateProp && templateHtml && decorator.getFirstChildByKind(SyntaxKind.CallExpression)
    .getFirstChildByKind(SyntaxKind.SyntaxList)
    .getFirstChildByKind(SyntaxKind.ObjectLiteralExpression)
    .getLastChildByKind(SyntaxKind.PropertyAssignment)
    .getFirstChildByKind(SyntaxKind.NoSubstitutionTemplateLiteral)

  const htmlAstTraverser = (ast, ...htmlTags) => {
    htmlTags.forEach(tag => {
      ast = ast.children.find(child => child.name === tag)
    })
    return ast
  }

  let htmlAst,
    astError,
    templateAst,
    div,
    h1,
    p

  before(async () => {
    const htmlValidatorPromise = new Promise((resolve, reject) => {
      htmlTagValidator(htmlCode, (err, ast) => err ? reject(err) : resolve(ast))
    })

    await htmlValidatorPromise.then(function (res) {
      htmlAst = res.document[0]
    }).catch((err) => {
      astError = err.message.replace(/to match closing tag .*/, 'to have a matching closing tag.')
    })

    if (templateHtml) {
      const templateValidatorPromise = new Promise((resolve, reject) => {
        htmlTagValidator(templateHtml, (err, ast) => err ? reject(err) : resolve(ast))
      })

      await templateValidatorPromise.then(function (res) {
        templateAst = res
        if (templateAst.document.length > 0 && templateAst.document[0].name === 'div') {
          div = templateAst.document[0]
          h1 = htmlAstTraverser(div, 'h1')
          p = htmlAstTraverser(div, 'p')
        }
      }).catch((err) => {
        astError = err.message.replace(/to match closing tag .*/, 'to have a matching closing tag.')
      })
    }
  })

  beforeEach(() => {
    const stmt = `Hmm, it seems there's something wrong with our code. \nWe are getting the following error:\n\n`
    if (astError !== undefined) {
      assert(false, `${stmt} \`${astError}\``)
    }
    assert(decorator, "Oops, it looks like we did not include a `@Component` decorator in our class.")
  });

  describe('Tasks', () => {
    it('f_valid_html', () => {
      const mainApp = htmlAstTraverser(htmlAst, 'body', 'main-app')
      assert(mainApp, "It looks like we still need to add the `main-app` tag to our html body.  Remember to close the `main-app` element and to not include any child text or elements.")
    })

    it('f_selector', () => {
      const selectorProp = properties.find(prop => prop.name.escapedText === 'selector')
      assert(selectorProp, "Let's make sure we've added `selector` as a property to our `@Component` decorator.")
      const selectorValue = properties.find(prop => prop.name.escapedText === 'selector').initializer.text
      assert(selectorValue === 'main-app', "Close! We have the `selector` property, now we need to double check that the value matches the html tag we added earlier.")
    })

    it('f_template', () => {
      const templateProp = properties.find(prop => prop.name.escapedText === 'template')
      assert(templateProp && decoratorComma, "Let's make sure we've added `template` as a property to our `@Component` decorator and separate the properties with a `,`.")
      assert(div && h1 && p && templateBacktick, "Uh-oh, let's make sure we're assigning the correct value to our `template` property and using backticks `` required to make our template literal.")
    })

    it('f_h1_reference', () => {
      assert(h1, "Let's make sure we have an `h1`.")
      const h1Text = h1.children.find(x => x.type === 'text').contents
      assert(/{{\s*pageTitle\s*}}/.test(h1Text), "Let's make sure we are referencing the `pageTitle` property from the `AppComponent` class inside the `h1` tag of our template.")
      assert(p, "Let's make sure we have a `p`.")
      const pText = p.children.find(x => x.type === 'text').contents
      assert(/{{\s*currentPromotion\s*}}/.test(pText), "Almost there! We just need to reference the `currentPromotion` property from the `AppComponent` class inside the `p` tag of our template.")
    })
  })
})
