import { Component } from '@angular/core';

@Component({
  
})
export class AppComponent {
  pageTitle: string = 'Carved Rock Fitness';
  currentPromotion: string = '20% off throughout the season';
}
