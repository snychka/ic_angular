module.exports = {
  ignore: [
    './src/tests/mocha.env.js',
    './src/tests/sr.js'
  ],
  require: [
    './src/tests/mocha.env',
    'ts-node/register'
  ],
  extension: [
    'ts'
  ],
  spec: "./src/tests/*.spec.ts",
  reporter: './src/tests/sr',
  quiet: true,
  bail: true
}