import { Component } from '@angular/core';

@Component({
  selector: 'main-app',
  template: `
  <div>
    <h1>{{pageTitle}}</h1>
  </div>
  <div>
    <ul>
      <li>Clothing</li>
      <li>Footwear</li>
      <li>Equipment</li>
      <li>Bags & Travel</li>
      <li>Trail Reviews</li>
    </ul>
  </div>
  `
})
export class AppComponent {
  pageTitle: string = 'Carved Rock Fitness';
}
