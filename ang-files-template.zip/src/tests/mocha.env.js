process.env.NODE_ENV = 'test'
process.env.TS_NODE_PROJECT = 'tsconfig.spec.json'