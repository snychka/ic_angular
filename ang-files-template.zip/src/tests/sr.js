class SimpleReporter {
  constructor(runner) {
    runner.on('pass', test => console.log(`Well Done!\n<pass>`))
          .on('fail', (test, err) => console.log(`${err.message.replace(/: expected(.*)$/, '')}\n<fail>`));
  }
}

module.exports = SimpleReporter;
