import { assert } from 'chai';
import { Project } from 'ts-morph';
import { readFileSync } from 'fs';
import { SyntaxKind } from 'typescript';
import { parse } from 'node-html-parser';

describe('extracting markup', () => {
  let decorator: any;
  let properties: any;
  let templateProp: any;
  let templateUrl: any;
  let templateHtml: any;
  let htmlAst: any;

  before(() => {
    const project = new Project();
    const appComponentCode = readFileSync('src/app/app.component.ts', 'utf-8');
    const appComponentHtml = readFileSync('src/app/app.component.html', 'utf-8');
    const appComponentAST = project.createSourceFile('src/compiled/app.component.ts', appComponentCode);
    htmlAst = parse(appComponentHtml);

    decorator = appComponentAST.getClass('AppComponent').getDecorator('Component');

    properties = decorator ? decorator.getArguments()[0].compilerNode.properties : undefined;
    templateProp = properties && properties.find(prop => prop.name.escapedText === 'template');
    templateUrl = properties && properties.find(prop => prop.name.escapedText === 'templateUrl');
    templateHtml = templateProp && templateProp.initializer && templateProp.initializer.text;
  })

  describe('one', () => {
    it('f_one_app_component_html_has_template', () => {
      assert(htmlAst.childNodes.length > 0, `Oops, let's paste the HTML from the \`template\` property into \`app.component.html\``);
    })

    it('f_one_template_not_empty', () => {
      if (templateProp) {
        assert(templateHtml.trim() === '', `Oops, let's remove the HTML from the template property, leaving empty quotes in its place.`)
      }
      return;
    })
  })

  describe('two', () => {
    it('f_two_template_url_exists', () => {
      assert(!templateProp && templateUrl, `Oops, let's replace the \`template\` property with the \`templateUrl\` property in the \`@Component\` decorator.`);
    })
  })
})
